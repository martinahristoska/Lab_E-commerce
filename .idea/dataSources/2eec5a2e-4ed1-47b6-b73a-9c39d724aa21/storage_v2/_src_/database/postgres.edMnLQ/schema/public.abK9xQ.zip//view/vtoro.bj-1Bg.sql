create view vtoro(broj_smetka_isplata, prosecen_priliv) as
SELECT transakcija.broj_smetka_isplata,
       avg(transakcija.suma) AS prosecen_priliv
FROM transakcija
GROUP BY transakcija.broj_smetka_isplata, (date_part('month'::text, transakcija.vreme_izvrsuvanje));

alter table vtoro
    owner to postgres;

