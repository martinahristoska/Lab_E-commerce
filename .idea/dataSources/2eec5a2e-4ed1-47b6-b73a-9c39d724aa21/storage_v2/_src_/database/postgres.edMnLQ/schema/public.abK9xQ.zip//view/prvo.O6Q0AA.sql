create view prvo(isplaten, uplakac, suma, valuta) as
SELECT c.ime  AS isplaten,
       c2.ime AS uplakac,
       t.suma,
       t.valuta
FROM transakcija t
         JOIN smetka s ON t.broj_smetka_isplata = s.broj_smetka
         JOIN klient k ON s.embg_klient = k.embg_klient
         JOIN covek c ON c.embg = k.embg_klient
         JOIN smetka su ON t.broj_smetka_uplata = su.broj_smetka
         JOIN klient k2 ON su.embg_klient = k2.embg_klient
         JOIN covek c2 ON c2.embg = k2.embg_klient
WHERE date_part('days'::text, t.vreme_izvrsuvanje) = date_part('days'::text, now())
  AND date_part('month'::text, t.vreme_izvrsuvanje) = date_part('month'::text, now())
  AND date_part('year'::text, t.vreme_izvrsuvanje) = date_part('year'::text, now())
  AND date_part('hour'::text, t.vreme_izvrsuvanje) <= 24::double precision;

alter table prvo
    owner to postgres;

