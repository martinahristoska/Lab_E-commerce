create view mesecni_transakcii2
            (ime_uplakjach, prezime_uplakjach, embg_uplakjach, ime_isplaten, prezime_isplaten, embg_isplaten,
             vreme_izvrsuvanje, suma, valuta)
as
SELECT chu.ime     AS ime_uplakjach,
       chu.prezime AS prezime_uplakjach,
       chu.embg    AS embg_uplakjach,
       chi.ime     AS ime_isplaten,
       chi.prezime AS prezime_isplaten,
       chi.embg    AS embg_isplaten,
       t.vreme_izvrsuvanje,
       t.suma,
       t.valuta
FROM transakcija t
         JOIN smetka su ON t.broj_smetka_uplata = su.broj_smetka
         JOIN klient ku ON su.embg_klient = ku.embg_klient
         JOIN covek chu ON ku.embg_klient = chu.embg
         JOIN smetka si ON t.broj_smetka_isplata = si.broj_smetka
         JOIN klient ki ON si.embg_klient = ki.embg_klient
         JOIN covek chi ON ki.embg_klient = chi.embg
WHERE date_part('month'::text, t.vreme_izvrsuvanje) = date_part('month'::text, now())
  AND date_part('year'::text, t.vreme_izvrsuvanje) = date_part('year'::text, now())
ORDER BY t.vreme_izvrsuvanje;

alter table mesecni_transakcii2
    owner to postgres;

