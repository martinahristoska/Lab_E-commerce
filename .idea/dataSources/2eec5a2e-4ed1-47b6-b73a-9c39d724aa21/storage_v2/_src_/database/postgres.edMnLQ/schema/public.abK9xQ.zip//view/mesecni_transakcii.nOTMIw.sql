create view mesecni_transakcii(ime, prezime, embg, suma, vreme_izvrsuvanje) as
SELECT cu.ime,
       cu.prezime,
       cu.embg,
       t.suma,
       t.vreme_izvrsuvanje
FROM transakcija t
         JOIN smetka su ON t.broj_smetka_uplata = su.broj_smetka
         JOIN klient ku ON su.embg_klient = ku.embg_klient
         JOIN covek cu ON ku.embg_klient = cu.embg
         JOIN smetka si ON t.broj_smetka_isplata = si.broj_smetka
         JOIN klient ki ON si.embg_klient = ki.embg_klient
         JOIN covek ci ON ki.embg_klient = ci.embg
WHERE date_part('month'::text, t.vreme_izvrsuvanje) = date_part('month'::text, now())
  AND date_part('year'::text, t.vreme_izvrsuvanje) = date_part('year'::text, now())
ORDER BY t.vreme_izvrsuvanje;

alter table mesecni_transakcii
    owner to postgres;

