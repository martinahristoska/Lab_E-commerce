create view mesecni_transakciii
            (ime2, prezime2, embg_uplakjach, ime, prezime, embg_isplaten, suma, vreme_izvrsuvanje) as
SELECT cu.ime     AS ime2,
       cu.prezime AS prezime2,
       cu.embg    AS embg_uplakjach,
       ci.ime,
       ci.prezime,
       ci.embg    AS embg_isplaten,
       t.suma,
       t.vreme_izvrsuvanje
FROM transakcija t
         JOIN smetka su ON t.broj_smetka_uplata = su.broj_smetka
         JOIN klient ku ON su.embg_klient = ku.embg_klient
         JOIN covek cu ON ku.embg_klient = cu.embg
         JOIN smetka si ON t.broj_smetka_isplata = si.broj_smetka
         JOIN klient ki ON si.embg_klient = ki.embg_klient
         JOIN covek ci ON ki.embg_klient = ci.embg
WHERE date_part('month'::text, t.vreme_izvrsuvanje) = date_part('month'::text, now())
  AND date_part('year'::text, t.vreme_izvrsuvanje) = date_part('year'::text, now())
ORDER BY t.vreme_izvrsuvanje;

alter table mesecni_transakciii
    owner to postgres;

