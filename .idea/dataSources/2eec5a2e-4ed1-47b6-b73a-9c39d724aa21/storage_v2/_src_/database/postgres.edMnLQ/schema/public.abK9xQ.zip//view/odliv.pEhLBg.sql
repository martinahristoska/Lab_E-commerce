create view odliv(odliv, broj_smetka_uplata, month, ime, prezime) as
SELECT sum(transakcija.suma)                                   AS odliv,
       transakcija.broj_smetka_uplata,
       date_part('month'::text, transakcija.vreme_izvrsuvanje) AS month,
       c.ime,
       c.prezime
FROM transakcija
         JOIN smetka s ON s.broj_smetka = transakcija.broj_smetka_uplata
         JOIN klient k ON k.embg_klient = s.embg_klient
         JOIN covek c ON c.embg = k.embg_klient
GROUP BY transakcija.broj_smetka_uplata, (date_part('month'::text, transakcija.vreme_izvrsuvanje)), c.ime, c.prezime;

alter table odliv
    owner to postgres;

